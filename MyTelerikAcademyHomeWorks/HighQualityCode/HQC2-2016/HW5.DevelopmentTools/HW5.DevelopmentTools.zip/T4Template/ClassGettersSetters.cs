﻿namespace T4Template
{
	class ClassGettersSetters
	{
		public int Item0 { get; set; }
		public int Item1 { get; set; }
		public int Item2 { get; set; }
		public int Item3 { get; set; }
		public int Item4 { get; set; }
		public int Item5 { get; set; }
		public int Item6 { get; set; }
		public int Item7 { get; set; }
	}
}