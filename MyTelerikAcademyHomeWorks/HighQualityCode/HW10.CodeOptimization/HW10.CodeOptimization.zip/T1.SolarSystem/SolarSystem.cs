﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T1.SolarSystem
{
    class SolarSystem
    {
        static void Main()
        {
            Console.WriteLine("Please, see the solar system optimization snapshots in the .png files:\n");
            Console.WriteLine("T1.SolarSystemBeforeFix.png");
            Console.WriteLine("T1.SolarSystemJustTrace.png");
            Console.WriteLine("T1.SolarSystemAfterFix.png\n");
        }
    }
}
