﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace T10.ShortestSequence
{
    public static class Operations
    {
        public static int OperationAddOne(int number)
        {
            return number + 1;
        }

        public static int OperationAddTwo(int number)
        {
            return number + 2;
        }

        public static int OperationMultiplyByTwo(int number)
        {
            return number * 2;
        }
    }     
}
