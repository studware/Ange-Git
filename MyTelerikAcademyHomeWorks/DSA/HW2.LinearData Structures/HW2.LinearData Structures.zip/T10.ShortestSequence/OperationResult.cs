﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace T10.ShortestSequence
{
    public struct OperationResult
    {
        public int Result;
        public string Generation;
    }
}
