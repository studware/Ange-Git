﻿namespace IntergalacticTravel.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using NUnit.Framework;

    [TestFixture]
    public class TeleportStationTests
    {
        [Test]//(owner, galacticMap & location)
        public void Constructor_WhenNewTeleportStationCreatedWithValidParams_ShouldSetUpAllProvidedFields()
        { 
        // Arrange

        // Act

        // Assert        
        }
    }
}
