﻿namespace IntergalacticTravel
{
    /// <summary>
    /// Imma dummy class
    /// </summary>
    internal class Lacaille : Unit
    {
        public Lacaille(int identificationNumber, string nickName) : base(identificationNumber, nickName)
        {
        }
    }
}
